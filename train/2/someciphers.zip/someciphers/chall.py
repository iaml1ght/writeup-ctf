import base64

def convert_string(string):
    s3 = ''
    unchanged_chars = []
    for index, char in enumerate(string):
        if char.isdigit():
            converted_char = chr(int(char) + ord('a'))
        else:
            converted_char = char
            unchanged_chars.append(f'{char}:{index}')
        s3 += converted_char
    return s3, unchanged_chars


flag = "FAKE-FLAG"
s2 = flag.encode().hex()
s3, unchanged_chars = convert_string(s2)
s4 = ''
k = base64.b64decode("aHV0ZWNoY3Rm").decode('utf-8')
for i in range(len(s3)):
    one = chr((ord(k[i % len(k)]) - 97 + ord(s3[i]) - 97) % 26 + 97)
    s4 += one
print(f'{", ".join(unchanged_chars)}')
print(s4)